<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="5; url=http://localhost/barangayProfiling/genReport.php">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap.min.css">
    <link rel="stylesheet" href="../styles/all.css">
    <style>
        body{
            margin-top:50px;
        }

    </style>

    <script type="text/javascript">
        window.onload = function() { window.print(); }
    </script>
    
</head>
<body>

                <div class="container">
                    <div class="row align-items-center justify-content-center">
                    <img src="../images/lapasanLogo.png" alt="Barangay Logo" width="170px" style="margin-right: 50px;">
                    <span>
                        <center>
                        <h2> BARANGAY LAPASAN </h2>
                        <h4> Residents Who are Issued With<br>Cert. for Business Permit </h4>
                        </center>
                    </span>
                    <img src="../images/cdoLogo.png" alt="Barangay Logo" width="150px" style="margin-left: 50px;">
                </div><br>
                <center>
                    <hr style="border-width: 10px; margin:0; border-color:black; width:850px">
                    <hr style="border-width: 5px; margin:5px; border-color:black; width:850px;">
                </center>
                <br><br>
                    <div class="col-md-12">   
                        <center>       
                        <table class="table" style="width: 850px;">
                            <thead style="color:black;">
                            <tr>
                                <th>NAME</th>
                                <th>AGE</th>
                                <th>GENDER</th>
                                <th>STATUS</th>
                                <th>ADDRESS</th>
                                <th>CONTACT#</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                                include_once('../utilities/dbconnect.php');

                                $sql = "SELECT * 
                                FROM residentsprofile INNER JOIN clearanceissuance 
                                ON residentsprofile.residentID = clearanceissuance.resID AND clearanceissuance.documentID = 3";
                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $dob = $row['dateOfBirth'];
                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <tr>
                                <td><?= $row['lastName']; ?>, <?= $row['firstName']; ?> <?= $row['midName']; ?> <?= $row['suffix']; ?></td>
                                <td><?= $age; ?></td>
                                <td><?= $row['gender']; ?></td>
                                <td><?= $row['civilStatus']; ?></td>
                                <td><?= $row['addDetails']; ?>, <?= $row['address']; ?></td>
                                <td><?= $row['contactNum']; ?></td>
                            </tr>
                            <?php
                                }
                            }
                            ?>
                            </tbody>
                        </table>
                        </center>
                    </div>
                </div>
</body>
</html>