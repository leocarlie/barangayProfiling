<?php 
    include_once('utilities/dbconnect.php');
    include_once('includes/template/adminHeader.php');
    include_once('includes/template/adminExpand.php');
?>