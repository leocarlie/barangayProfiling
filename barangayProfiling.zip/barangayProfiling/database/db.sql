-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2020 at 08:34 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brgyprofiling`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'bangonlapasan', 'brgylapasan123');

-- --------------------------------------------------------

--
-- Table structure for table `clearancedoc`
--

CREATE TABLE `clearancedoc` (
  `documentID` int(11) NOT NULL,
  `documentName` varchar(50) NOT NULL,
  `documentFee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clearancedoc`
--

INSERT INTO `clearancedoc` (`documentID`, `documentName`, `documentFee`) VALUES
(1, 'Cert of Indigency', 50),
(2, 'Cert of Residency', 60),
(3, 'Brgy Clearance', 70),
(4, 'Cert for Business Permit', 80),
(5, 'Cert for Water Connection', 90),
(6, 'Cert for Electrical Connection', 100);

-- --------------------------------------------------------

--
-- Table structure for table `clearanceissuance`
--

CREATE TABLE `clearanceissuance` (
  `issuanceID` int(11) NOT NULL,
  `resID` int(11) NOT NULL,
  `documentID` int(11) NOT NULL,
  `dateIssued` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clearanceissuance`
--

INSERT INTO `clearanceissuance` (`issuanceID`, `resID`, `documentID`, `dateIssued`) VALUES
(1, 2028, 2, '2020-09-23 06:03:06');

-- --------------------------------------------------------

--
-- Table structure for table `clearancerequest`
--

CREATE TABLE `clearancerequest` (
  `requestID` int(11) NOT NULL,
  `resID` int(11) NOT NULL,
  `documentID` int(11) NOT NULL,
  `requestDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `requestPurpose` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clearancerequest`
--

INSERT INTO `clearancerequest` (`requestID`, `resID`, `documentID`, `requestDate`, `requestPurpose`, `status`) VALUES
(1, 2028, 2, '2020-09-23 05:56:16', 'NBI Clearance', 'Released'),
(2, 2025, 1, '2020-09-23 05:57:16', 'Scholarship', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `residentsprofile`
--

CREATE TABLE `residentsprofile` (
  `residentID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `midName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `suffix` varchar(50) DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `civilStatus` varchar(50) NOT NULL,
  `contactNum` char(11) NOT NULL,
  `brgyposition` varchar(50) NOT NULL,
  `addDetails` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `dateAdded/Updated` timestamp NOT NULL DEFAULT current_timestamp(),
  `livingStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `residentsprofile`
--

INSERT INTO `residentsprofile` (`residentID`, `firstName`, `midName`, `lastName`, `suffix`, `dateOfBirth`, `gender`, `civilStatus`, `contactNum`, `brgyposition`, `addDetails`, `address`, `dateAdded/Updated`, `livingStatus`) VALUES
(2022, 'Dan David', 'Lee', 'Abanilla', 'Jr.', '1998-03-19', 'Male', 'Single', '09398885941', 'SK. Chairman ', '23, Aurora Bldg.', 'Bajas Rd., Lapasan, Cagayan de Oro City', '2020-09-21 20:59:29', 'Active'),
(2023, 'Dane Danielle', 'Scott', 'Agustine', 'Sr.', '1998-03-19', 'Female', 'Married', '09355146234', 'Zone Leader', 'Block 12', 'San Juan Access Rd., Lapasan, Cagayan de Oro City', '2020-09-21 21:04:19', 'Active'),
(2024, 'Rejan Vincent', 'Brooklyn', 'Onting', '', '1998-03-09', 'Male', 'Divorced', '09758885941', 'Brgy. Councilor', 'Room 23, Aguinaldo Bldg.', 'Mambato St., Lapasan, Cagayan de Oro City', '2020-09-21 21:05:40', 'Active'),
(2025, 'Leo Carlie', 'Agobato', 'Abato', '', '1998-03-19', 'Male', 'Single', '09398885941', 'Resident', 'Room 1, Auroras Bldg.', 'Baconga St., Lapasan, Cagayan de Oro City', '2020-09-21 21:07:25', 'Active'),
(2026, 'Richie Marie', 'Einstein', 'Gatela', 'Sr.', '1999-03-19', 'Female', 'Widow', '09355146234', 'Committee on IPW', 'Block Z', 'Sto. Nino St., Lapasan, Cagayan de Oro City', '2020-09-21 21:10:47', 'Active'),
(2027, 'Peter', 'Babs', 'Babia', '', '1997-03-19', 'Male', 'Divorced', '09758885941', 'Brgy. Captain', 'Room 1, Aguinaldo Bldg.', 'Hillside Rd., Lapasan, Cagayan de Oro City', '2020-09-21 21:13:41', 'Active'),
(2028, 'John Doe', 'Doey Joey', 'Joe', '', '1990-12-05', 'Male', 'Divorced', '09758885941', 'Resident', 'Block 5', 'Kabukiran St., Lapasan, Cagayan de Oro City', '2020-09-21 21:16:46', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clearancedoc`
--
ALTER TABLE `clearancedoc`
  ADD PRIMARY KEY (`documentID`);

--
-- Indexes for table `clearanceissuance`
--
ALTER TABLE `clearanceissuance`
  ADD PRIMARY KEY (`issuanceID`);

--
-- Indexes for table `clearancerequest`
--
ALTER TABLE `clearancerequest`
  ADD PRIMARY KEY (`requestID`);

--
-- Indexes for table `residentsprofile`
--
ALTER TABLE `residentsprofile`
  ADD PRIMARY KEY (`residentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clearancedoc`
--
ALTER TABLE `clearancedoc`
  MODIFY `documentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `clearanceissuance`
--
ALTER TABLE `clearanceissuance`
  MODIFY `issuanceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clearancerequest`
--
ALTER TABLE `clearancerequest`
  MODIFY `requestID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `residentsprofile`
--
ALTER TABLE `residentsprofile`
  MODIFY `residentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2030;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
