<?php
    include_once('utilities/dbconnect.php');
    include_once('includes/template/header.php');    
?>

<div class="container-fluid" style="margin-top: 15px; background-image: url(images/loginbg.jpg); background-repeat: no-repeat; background-size: cover; height: auto;">
    <div class="row">
        <div class="col-md-7" style="background-color: rgba(158, 0, 0, .8); padding: 10px; height:650px;">
            <a href="index.php" style="padding: 0;"><button class="btn" style="width: 60px;"><i class="fas fa-arrow-circle-left" style="color: white; font-size: 30px;"></i></button></a>
            <center>
                <img src="images/lapasanLogo.png" alt="Barangay Logo" width="200px" height="200px" style="margin-top: 100px;">
                <h1 style="margin:10px 0 0 0; font-size:50px;">BARANGAY</h1>
                <h1 style="font-size: 100px; margin:0;">LAPASAN</h1>
            </center>
        </div>
        <div class="col-md-5 mt-5" style="padding: 100px;">
            <center>
                <i class="fas fa-user" style="color: rgb(192 0 0); font-size:100px; margin-top:40px; margin-bottom:10px;"></i>
                <div style="border-radius: 20px 20px 20px 20px; border-style:solid; border-color:white; border-width:2px;"><br>
                    <div class="col-md-12">
                        <form action="transactions/adminLogin.php" method="post" style="color: white;">
                            <div style="margin: 5px; border-radius:10px; background-color:white; padding:5px;">
                                <i class="fas fa-user" style="color: black;"></i>
                                <input style="background-color: rgba(0, 0, 0, 0); border-color: rgba(0, 0, 0, 0); color:black;" type="text" name="username" placeholder="Enter Barangay Username" required>
                            </div>
                            <div style="margin: 5px; border-radius:10px; background-color:white; padding:5px;">
                                <i class="fas fa-key" style="color: black;"></i>
                                <input style="background-color: rgba(0, 0, 0, 0); border-color: rgba(0, 0, 0, 0); color:black;" type="password" name="password" placeholder="Enter Barangay Password" required>
                            </div>
                                <br>
                                <button type="submit" class="btn mb-4" style="width: 200px; color:white; background-color: rgb(192, 0, 0); font-size: 20px;">Login</button>
                                
                        </form>
                    </div>
                </div>
            </center>
            <span style="position: absolute; color:white;">
                <?php
                    if(isset($_GET['msg'])){
                    echo $_GET['msg'];
                    } 
                ?>
            </span>
        </div>
    </div>
</div>
