<?php 
    include_once('utilities/dbconnect.php');
    include_once('includes/template/adminheader.php');
    include_once('includes/template/update.php');
?>