<?php
    include_once('../utilities/dbconnect.php');

   
    $newresID = $_GET['id'];
    $newfname = $_GET['fname'];
    $newmname = $_GET['mname'];
    $newlname = $_GET['lname'];
    $newsuffix = $_GET['suffix'];
    $newgender = $_GET['gender'];
    $newstatus = $_GET['status'];
    $newdob = $_GET['dob'];
    $newnum = $_GET['number'];
    $newpos = $_GET['position'];
    $newAddDetails = $_GET['addDetails'];
    $newadd = $_GET['address'];
    $newLStatus = $_GET['lStatus'];


    $sql = "SELECT * FROM residentsprofile WHERE residentID = '$newresID'";
    $data = mysqli_query($conn, $sql);
    
    if(mysqli_num_rows($data) == 1){

            // update
            $sql = "UPDATE residentsprofile SET firstName = '$newfname', midName = '$newmname', lastName = '$newlname', suffix = '$newsuffix', dateOfBirth = '$newdob', gender = '$newgender', civilStatus = '$newstatus', contactNum = '$newnum', brgyposition = '$newpos', addDetails = '$newAddDetails', address = '$newadd', livingStatus = '$newLStatus' WHERE residentID = '$newresID'";

            if(mysqli_query($conn, $sql)){
                header("location: ../residentsProfile.php");
                echo "Successful update";
                echo $newfname;
                echo $newlname;

            }else{
                echo "Failed to update";
            }     
            
    }

?>