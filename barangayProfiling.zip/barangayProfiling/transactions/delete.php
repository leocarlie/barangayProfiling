<?php
    include_once('../utilities/dbconnect.php');

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $resID = $_GET['residentID'];
    $sql = "DELETE FROM residentsprofile WHERE residentID = '$resID'";
    
    if(mysqli_query($conn, $sql)){
        header("location: ../residentsProfile.php");
    }else{
        echo "Failed to Delete";
    } 

?>