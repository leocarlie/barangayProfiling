<?php

    include_once('../utilities/dbconnect.php');

    $list = $_GET['list'];
    $gender = $_GET['gender'];
    $cType = $_GET['cType'];
    
    if($list == 'residents'){
        header("Location: ../genReports/listResidents.php");
    }else if($list == 'gender'){
        if($gender == 'male'){
            header("Location: ../genReports/listMale.php");
        }else if($gender == 'female'){
            header("Location: ../genReports/listFemale.php");
        }
    }else if($list == 'requested'){
        if($cType == 1){
            header("Location: ../genReports/listR1.php");
        }else if($cType == 2){
            header("Location: ../genReports/listR2.php");
        }else if($cType == 3){
            header("Location: ../genReports/listR3.php");
        }else if($cType == 4){
            header("Location: ../genReports/listR4.php");
        }else if($cType == 5){
            header("Location: ../genReports/listR5.php");
        }else if($cType == 6){
            header("Location: ../genReports/listR6.php");
        }
    }else if($list == 'issued'){
        if($cType == 1){
            header("Location: ../genReports/listI1.php");
        }else if($cType == 2){
            header("Location: ../genReports/listI2.php");
        }else if($cType == 3){
            header("Location: ../genReports/listI3.php");
        }else if($cType == 4){
            header("Location: ../genReports/listI4.php");
        }else if($cType == 5){
            header("Location: ../genReports/listI5.php");
        }else if($cType == 6){
            header("Location: ../genReports/listI6.php");
        }
    }

?>

