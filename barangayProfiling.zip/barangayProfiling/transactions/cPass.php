<?php

    include_once('../utilities/dbconnect.php');

    $oldPass = $_GET['oldPass'];
    $newPass = $_GET['newPass'];
    $confirm = $_GET['confirm'];
    
    $sql = "SELECT * FROM admin";
    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) == 1){
        while($row = mysqli_fetch_assoc($result)){
            $pass = $row['password'];
        }
    }

    if($oldPass == $pass){
        if($newPass == $confirm){
            $update = "UPDATE admin SET password = '$newPass'";
            if(mysqli_query($conn, $update)){
                // Initialize the session.
                session_start();
                // Unset all of the session variables.
                unset($_SESSION['username']);
                unset($_SESSION['password']);
                // Finally, destroy the session.    
                session_destroy();

                header("location: ../index.php");
            }
            echo "Welcome Admin!";
        }else{
            $msg = "Confirm Password is Incorrect!";
            header("location: ../cPass.php?msg=$msg");
        }
    }else{
        $msg = "Incorrect Old Password!";
        header("location: ../cPass.php?msg=$msg");
    }

?>

