<?php

    include_once('../utilities/dbconnect.php');

    $id = $_POST['id'];
    $ctype = $_POST['ctype'];
    $purpose = $_POST['purpose'];
    $status = $_POST['status'];



        $sql = "INSERT INTO clearancerequest 
        (resID, documentID, requestPurpose, status) 
        VALUES 
        ('$id', '$ctype', '$purpose', '$status')";
         
        if(mysqli_query($conn, $sql)){
             header("Location: ../queueMessage.php");
        }
        else{
             echo "Error!";
        }
?>
