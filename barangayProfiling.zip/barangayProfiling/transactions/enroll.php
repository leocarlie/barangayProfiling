<?php

    include_once('../utilities/dbconnect.php');

    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $suffix = $_POST['suffix'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $status = $_POST['status'];
    $number = $_POST['number'];
    $position = $_POST['position'];
    $addDetails = $_POST['addDetails'];
    $address = $_POST['address'];
    $lStatus = $_POST['lStatus'];



        $query = "INSERT INTO residentsprofile 
        (firstName, midName, lastName, suffix, dateOfBirth, gender, civilStatus, contactNum, brgyposition, addDetails, address, livingStatus) 
        VALUES 
        ('$fname', '$mname', '$lname', '$suffix', '$dob', '$gender', '$status', '$number', '$position', '$addDetails', '$address', '$lStatus')";
         
        if(mysqli_query($conn, $query)){
          header("Location: ../admin.php");
        }else{
          echo "Error Adding Resident!";
        }

?>
