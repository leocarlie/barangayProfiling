<?php

    include_once('../utilities/dbconnect.php');

    // Initialize the session.
    session_start();
    // Unset all of the session variables.
    unset($_SESSION['username']);
    unset($_SESSION['password']);
    // Finally, destroy the session.    
    session_destroy();

    header("location: ../index.php");


?>


