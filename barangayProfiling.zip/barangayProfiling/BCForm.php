<?php 
    include_once('utilities/dbconnect.php');
    include_once('includes/template/adminHeader.php');
        $reqID = $_GET['requestID'];
        $resID = "SELECT * FROM clearancerequest WHERE requestID = $reqID";
        $result = mysqli_query($conn, $resID);
        if(mysqli_num_rows($result) == 1 ){
            while($row = mysqli_fetch_assoc($result)){
                $resident = $row['resID'];
                $purpose = $row['requestPurpose'];
                $docID = $row['documentID'];
            }
        }
        
        $fetchRes = "SELECT * FROM residentsprofile WHERE residentID = $resident";
        $resultFetch = mysqli_query($conn, $fetchRes);
        if(mysqli_num_rows($resultFetch) == 1 ){
            while($row = mysqli_fetch_assoc($resultFetch)){
                
                $dob = $row['dateOfBirth'];
                $bday = new DateTime($dob); // Your date of birth
                $today = new Datetime(date('y.m.d'));
                $diff = $today->diff($bday);
                $age = $diff->y;

                $day = date("jS \of F Y");
        
?>

<div class="container" style="background-color:gray; padding:10px;">
    <div class="row OCIFormrow1 p-1 align-items-center">
        <a href="viewBCRequest.php"><i class="fas fa-window-close" style="color: white; font-size:40px;"></i></a>
        <h1 style="color: white; margin-top:10px;">Brgy. Clearance Issuance Form</h1>
    </div>
    <div style="margin: 20px; padding: 10px; background-color:white;">
        <center>
            <form class="form-horizontal OCIForm" role="form" method="get" action="barangayClearance.php">
                <div class="form-group" style="display: none;">
                    <label class="control-label col-sm-2" for="day">DATE:</label>
                    <div class="col-sm-8">
                        <input type="text" name="day" value="<?= $day; ?>" class="form-control" placeholder="First Name" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="fname">FIRST NAME:</label>
                    <div class="col-sm-8">
                        <input type="text" name="fname" value="<?= $row['firstName']; ?>" class="form-control" placeholder="First Name" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="mname">MIDDLE NAME:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="lname">LAST NAME:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="suffix">SUFFIX:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="age">AGE:</label>
                    <div class="col-sm-8"> 
                        <input type="number" name="age" value="<?= $age ?>" class="form-control" placeholder="Enter Your Age Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="status">CIVIL STATUS:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="address">ADDRESS:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="purpose">PURPOSE:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="purpose" value="<?= $purpose; ?>" class="form-control" placeholder="Enter Requester's Name Here" required>
                    </div>
                </div>

                <div class="form-group" style="display: none;">
                    <label class="control-label col-sm-2" for="reqID">ReqID:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="reqID" value="<?= $reqID; ?>" class="form-control"  required>
                    </div>
                </div>
                <div class="form-group" style="display: none;">
                    <label class="control-label col-sm-2" for="resID">ResID:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="resID" value="<?= $resident; ?>" class="form-control"  required>
                    </div>
                </div>
                <div class="form-group" style="display: none;">
                    <label class="control-label col-sm-2" for="docID">DocID:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="docID" value="<?= $docID; ?>" class="form-control"  required>
                    </div>
                </div>
                <br>
                <div class="form-group"> 
                    <center>
                        <div class="col-sm-12 col-lg-8">
                            <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white;">View/Print PDF of Clearance</button>
                        </div>
                    </center>
                </div>
            </form>
        </center>
    </div>
</div>
<?php
    }
}
?>