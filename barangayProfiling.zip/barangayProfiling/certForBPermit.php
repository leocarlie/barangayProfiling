<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="5; url=http://localhost/barangayProfiling/viewBPRequest.php">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/all.css">
    <title>BPermit</title>
    <style>
        body{
            margin: 5px;
            margin-top: 70px;
        }

        img.logo{
            height: 150px;
            margin: 20px;
        }

        .brgylogo{
            float: left;
        }

        .mcpllogo{
            float: right;
        }

        .title{
            text-decoration: underline;
            font-family: arial black;
        }

        .content{
            margin: 70px 90px 0px 90px;
        }
    </style>

    <script type="text/javascript">
        window.onload = function() { window.print(); }
    </script>
</head>
<body>

        <?php

            include_once('utilities/dbconnect.php');

            $capt = "SELECT * from residentsprofile WHERE brgyposition LIKE '%Brgy. Captain%'";

            $result = mysqli_query($conn, $capt);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                    $Captfname = $row['firstName'];
                                    $Captmname = $row['midName'];
                                    $Captlname = $row['lastName'];
                                    $Captsuffix = $row['suffix'];

                                    $year = date("Y");

                                    }}
        ?>

        <div class="container-fluid">
            <div class="row align-items-center justify-content-center">
                <img src="images/lapasanLogo.png" alt="Barangay Logo" class="brgylogo logo" style="margin-right: 50px;">
                <span>
                    <center>
                    <h5> Republic of the Philippines </h5>
                    <h5> City of Cagayan de Oro </h5>
                    <h4> BARANGAY LAPASAN </h4>
                    <h4> OFFICE OF THE BARANGAY CHAIRMAN </h4>
                     Tel. No.: (08822) 881-9850 <br>
                    Email: godblesslapasan2018@gmail.com 
                    </center>
                </span>
                <img src="images/cdoLogo.png" alt="Barangay Logo" class="mcpllogo logo" style="margin-left: 50px;">
            </div><br>
            <div class="row justify-content-center">
                <h3 class="title">CERTIFICATION</h3>
            </div>

            <?php

                $fname = $_GET['fname'];
                $mname = $_GET['mname'];
                $lname = $_GET['lname'];
                $suffix = $_GET['suffix'];
                $age = $_GET['age'];
                $status = $_GET['status'];
                $address = $_GET['address'];
                $bCat = $_GET['bcategory'];
                $bLoc = $_GET['blocation'];
                $tName = $_GET['tName'];
                $ar = $_GET['AorR'];
                $day = $_GET['day'];


                $docID = $_GET['docID'];
                $resID = $_GET['resID'];
                $reqID = $_GET['reqID'];
                $find = "SELECT * FROM clearancerequest WHERE requestID = '$reqID'";
                $resFind = mysqli_query($conn, $find);


                if(mysqli_num_rows($resFind) == 1){
                    // update clearance request
                    $update = "UPDATE clearancerequest SET status = 'Released' WHERE requestID = '$reqID'";
                    if(mysqli_query($conn, $update)){
                        echo "";
                    }

                }


                    //insert to clearance issuance
                    $insert = "INSERT INTO clearanceissuance (resID, documentID) 
                    VALUES ('$resID', '$docID')";
                    if(mysqli_query($conn, $insert)){
                        echo "";
                    }

                
            ?>

            <div class="row">
                <p class="content" style="font-size:20px;">
                    TO WHOM IT MAY CONCERN: <br><br> 
                    <span style="margin-left: 50px;"></span> This is to certify that <span><b><?= $fname; ?> <?= $mname; ?> <?= $lname; ?> <?= $suffix; ?></b>,</span> <?= $age; ?> years old, <?= $status; ?> and presently residing at <?= $address; ?>, Lapasan, Cagayan De Oro City, has engaged a business of <b><?= $bCat; ?></b> located at <b><?= $bLoc; ?></b> in this city with the Trade Name of <b><?= $tName; ?></b>. <br><br>

                    <span style="margin-left: 50px;"></span>Furthermore, the Baranggay Council of Lapasan has no objection to the operation of the establishment provided that the following are complied, to with: <br>
                    
                    <span style="margin-left: 50px;"></span>1.	Pay all Baranggay Permit and clearances fees as may be required by the Lapasan Baranggay Council; <br>
                    <span style="margin-left: 50px;"></span>2.	Exercise due care and diligence in maintaining hygience and sanitation in the business establishment: <br>
                    <span style="margin-left: 50px;"></span>3.	Provided the necessary facility/equipment in the establishment so as not to disturb the tranquility in the neighborhood especially during the night time; <br>
                    <span style="margin-left: 50px;"></span>4.	Display in conspicuous place in the establishment visible to the public view the City Business Permit and this Baranggay Certificate; and <br>
                    <span style="margin-left: 50px;"></span>5.	Comply all requirements imposed by the city and national government. <br><br>

                    <span style="margin-left: 50px;"></span>This certification is issued upon the request of the above named person for his/her desire to <b><?= $ar; ?></b> for Business permit for the year <b><?= $year; ?></b>. <br>
                    <span style="margin-left: 50px;"></span>Done <?= $day; ?> at Lapasan, Cagayan de Oro City.
                </p>
            </div><br><br><br>
            <div style="float: right; margin-right: 120px;">
                <center>
                <h5 style="text-decoration: underline;"><b>Hon. <?= $Captfname; ?> <?= $Captmname; ?> <?= $Captlname; ?> <?= $Captsuffix; ?></b></h5>
                <p>Punong Barangay</p>
                </center>
            </div>
        </div>
<br><br><br>
    <pre style="float: right; margin-right: 120px; margin-bottom: 20px; font-size: 12px; border-width:0;">*not valid without official dry seal </pre>
</body>
</html>
