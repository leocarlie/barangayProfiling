<?php 
    include_once('utilities/dbconnect.php');
    include_once('includes/template/header.php');
    include_once('includes/template/banner.php');
    include_once('includes/template/developersSidebar.php');
    include_once('includes/template/developers.php');
?>