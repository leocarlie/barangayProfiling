<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="5; url=http://localhost/barangayProfiling/viewIRequest.php">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/all.css">
    <title>CIndigency</title>
    <style>
        body{
            margin: 5px;
            margin-top: 90px;
        }

        img.logo{
            height: 150px;
            margin: 20px;
        }

        .brgylogo{
            float: left;
        }

        .mcpllogo{
            float: right;
        }

        .title{
            text-decoration: underline;
            font-family: arial black;
        }

        .content{
            margin: 70px 90px 0px 90px;
        }
    </style>

    <script type="text/javascript">
        window.onload = function() { window.print(); }
    </script>
</head>
<body>

        <?php

            include_once('utilities/dbconnect.php');

            $capt = "SELECT * from residentsprofile WHERE brgyposition LIKE '%Brgy. Captain%'";

            $result = mysqli_query($conn, $capt);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                    $Captfname = $row['firstName'];
                                    $Captmname = $row['midName'];
                                    $Captlname = $row['lastName'];
                                    $Captsuffix = $row['suffix'];

                                    $date = date("jS \of F Y");
                                    

                                    }}
        ?>

        <div class="container-fluid">
            <div class="row align-items-center justify-content-center">
                <img src="images/lapasanLogo.png" alt="Barangay Logo" class="brgylogo logo" style="margin-right: 50px;">
                <span>
                    <center>
                    <h5> Republic of the Philippines </h5>
                    <h5> City of Cagayan de Oro </h5>
                    <h4> BARANGAY LAPASAN </h4>
                    <h4> OFFICE OF THE BARANGAY CHAIRMAN </h4>
                     Tel. No.: (08822) 881-9850 <br>
                    Email: godblesslapasan2018@gmail.com 
                    </center>
                </span>
                <img src="images/cdoLogo.png" alt="Barangay Logo" class="mcpllogo logo" style="margin-left: 50px;">
            </div><br><br><br>
            <div class="row justify-content-center">
                <h3 class="title">CERTIFICATE OF INDIGENCY</h3>
            </div>
            <br>

            <?php

                $fname = $_GET['fname'];
                $mname = $_GET['mname'];
                $lname = $_GET['lname'];
                $suffix = $_GET['suffix'];
                $age = $_GET['age'];
                $status = $_GET['status'];
                $address = $_GET['address'];
                $reqBy = $_GET['by'];
                $rel = $_GET['relationship'];
                $purpose = $_GET['purpose'];
                $day = $_GET['day'];


                $docID = $_GET['docID'];
                $resID = $_GET['resID'];
                $reqID = $_GET['reqID'];
                $find = "SELECT * FROM clearancerequest WHERE requestID = '$reqID'";
                $resFind = mysqli_query($conn, $find);


                if(mysqli_num_rows($resFind) == 1){
                    // update clearance request
                    $update = "UPDATE clearancerequest SET status = 'Released' WHERE requestID = '$reqID'";
                    if(mysqli_query($conn, $update)){
                        echo "";
                    }

                }


                    //insert to clearance issuance
                    $insert = "INSERT INTO clearanceissuance (resID, documentID) 
                    VALUES ('$resID', '$docID')";
                    if(mysqli_query($conn, $insert)){
                        echo "";
                    }

                
            ?>


            <div class="row">
                <p class="content" style="font-size:20px;">
                    TO WHOM IT MAY CONCERN: <br><br> 
                    <span style="margin-left: 50px;"></span>This is to certify that <span><b> <?= $fname; ?> <?= $mname; ?> <?= $lname; ?> <?= $suffix; ?> </b>,</span> <?= $age; ?> years old, <?= $status; ?> and a resident of <?= $address; ?> is an indigent as stated in his/her Sitio Clearance submitted to this office. <br><br>
                    
                    <span style="margin-left: 50px;"></span>This certification is issued upon the request of his/her <?= $rel; ?> <?= $reqBy; ?> as requirement for <span><b> <?= $purpose; ?> </b></span> intented for whatever legal intent it may serve him/her best. <br><br>
                    
                    <span style="margin-left: 50px;"></span>Issued this <?= $day; ?> at Lapasan, Cagayan de Oro City.
                </p>
            </div><br><br><br><br><br><br>
            <div style="float: right; margin-right: 120px;">
                <center>
                <h5 style="text-decoration: underline;"><b>Hon. <?= $Captfname; ?> <?= $Captmname; ?> <?= $Captlname; ?> <?= $Captsuffix; ?></b></h5>
                <p>Punong Barangay</p>
                </center>
            </div>
        </div>
<br><br><br><br><br><br><br><br><br>
    <pre style="float: right; margin-right: 120px; margin-bottom: 20px; font-size: 12px; border-width:0;">*not valid without official dry seal </pre>
</body>
</html>