<!--Center content begins here-->
<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li style="background-color: rgb(192, 0, 0)"><a href="#"><i class="fas fa-home"></i>Home</a></li>
                    <li><a href="contactUs.php"><i class="fas fa-phone"></i>Contact Us</a></li>
                    <li><a href="developers.php"><i class="fas fa-puzzle-piece"></i>Developers</a></li>
                    <br>
                    <li><a href="adminLogin.php"><i class="fas fa-user"></i>Login</a></li>
                </ul>
            </div>
        </nav>
    </div>