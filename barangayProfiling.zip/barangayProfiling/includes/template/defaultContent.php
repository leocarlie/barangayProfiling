
<?php

include_once('utilities/dbconnect.php');
  
// query to fetch Username and Password from 
// the table geek 
$query = "SELECT residentID FROM residentsprofile"; 
$numMale = "SELECT * FROM residentsprofile WHERE gender LIKE '%Male%'";
$numFemale = "SELECT * FROM residentsprofile WHERE gender LIKE '%Female%'";
  
// Execute the query and store the result set 
$result = mysqli_query($conn, $query);    
if ($result){ 
    // it return number of rows in the table. 
    $row = mysqli_num_rows($result); 
      
        if ($row) { 
            $population = $row; 
        }else{
            $population = 0;
        }
    // close the result. 
    mysqli_free_result($result); 
} 


$resultFemale = mysqli_query($conn, $numFemale);
if($resultFemale){
    $femaleRow = mysqli_num_rows($resultFemale);
    if($femaleRow){
        $female = $femaleRow;
    }else{
        $female = 0;
    }
}

$resultMale = mysqli_query($conn, $numMale);
if($resultMale){
    $maleRow = mysqli_num_rows($resultMale);
    if($maleRow){
        $male = $maleRow - $female;
    }else{
        $male = 0;
    }
}


// Connection close  
mysqli_close($conn);

?>
  
<div class="col-md-10">
    
        <div class="contentcontainer container-fluid">
            <div class="row">
                <div class="col-md-6 contentboxes">
                    <h6>Total Population</h6>
                    <div class="populationnumber">
                        <h1 class="population"><?= $population; ?></h1>
                    </div>
                </div>
                <div class="col-md-5 contentboxes">
                    <h6>Breakdown</h6>
                    <center>
                    <div class="male">
                        <h6 class="gender">Male</h6>
                        <h1 class="male"><?= $male; ?></h1>
                    </div>
                    <div class="female">
                        <h6 class="gender">Female</h6>
                        <h1 class="female"><?= $female; ?></h1>
                    </div>
                    </center>
                </div>
            </div>
        </div>
        <br>
        <div>
            <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
        </div>
    </div>
</div>
<!--Center content ends here-->