

<div class="container" style="background-color:gray; padding:10px;">
    <div class="row enrollrow1 p-1 align-items-center">
        <a href="residentsProfile.php"><i class="fas fa-window-close" style="color: white; font-size:40px;"></i></a>
        <h1 style="color: white; margin-top:10px;">Update Resident's Information</h1>
    </div>
    <div style="margin: 20px; padding: 10px; background-color:white;">
        <center>
            <form class="form-horizontal" role="form" method="get" action="transactions/update.php">

            <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $resID = $row['residentID'];
                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $dob = $row['dateOfBirth'];
                                        $num = $row['contactNum'];
                                        $pos = $row['brgyposition'];
                                        $addDetails = $row['addDetails'];
                                        $add = $row['address'];
                                        $lStatus = $row['livingStatus'];

                                    
                            ?>
                <div class="form-group" style="display: none;">
                    <label class="control-label col-sm-2" for="id">ID:</label>
                    <div class="col-sm-8">
                        <input type="text" name="id" value="<?= $resID ?>" class="form-control" placeholder="Your ID" required>
                    </div>
                </div>


                <div class="form-group">
                    <label class="control-label col-sm-2" for="fname">FIRST NAME:</label>
                    <div class="col-sm-8">
                        <input type="text" name="fname" value="<?= $fname ?>" class="form-control" placeholder="Enter Your First Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="mname">MIDDLE NAME:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="mname" value="<?= $mname ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="lname">LAST NAME:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="lname" value="<?= $lname ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="suffix">SUFFIX:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="suffix" value="<?= $suffix ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="gender">GENDER:</label>
                    <div class="col-sm-8"> 
                        <select name="gender" id="gender" class="form-control" required>
                            <option value="<?= $gender ?>"><?= $gender; ?></option>
                            <option value="MALE">Male</option>
                            <option value="FEMALE">Female</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="status">CIVIL STATUS:</label>
                    <div class="col-sm-8"> 
                        <select name="status" id="status" class="form-control" required>
                            <option value="<?= $status ?>"><?= $status ?></option>
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                            <option value="Divorced">Divorced</option>
                            <option value="Widow">Widow</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="dob">DATE OF BIRTH:</label>
                    <div class="col-sm-8"> 
                        <input type="date" name="dob" value="<?= $dob ?>" class="form-control" placeholder="Enter Date of Birth">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4" for="contact">CONTACT NUMBER:</label>
                    <div class="col-sm-8"> 
                        <input type="text" name="number" value="<?= $num ?>" class="form-control" placeholder="09xxxxxxxxx (11 numbers)">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4" for="position">BARANGAY POSITION:</label>
                    <div class="col-sm-8"> 
                        <select name="position" id="position" class="form-control">
                            <option value="<?= $pos ?>"><?= $pos ?></option>
                            <option value="Resident">Resident</option>
                            <option value="Brgy. Captain">Brgy. Kapitan</option>
                            <option value="Brgy. Councilor">Brgy. Kagawad</option>
                            <option value="SK. Chairman ">SK. Chairman</option>
                            <option value="SK. Chairwoman">SK. Chairwoman</option>
                            <option value="SK. Councilor">SK. Kagawad</option>
                            <option value="Zone Leader">Zone Leader</option>
                            <option value="Brgy. Worker or Staff">Barangay Worker/Staff</option>
                            <option value="Committee on IPW">Committee on Infrastracture Public Works</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4" for="addDetails">Address Details:</label>
                    <div class="col-sm-5"> 
                        <input type="text" name="addDetails" value="<?= $addDetails; ?>" class="form-control" placeholder="Address Details" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4" for="address">St./Ave./Rd.</label>
                    <div class="col-sm-5"> 
                        <select name="address" id="address" class="form-control" required>
                            <option value="<?= $add ?>"><?= $add ?></option>
                            <option value="Claro M. Recto Ave., Lapasan, Cagayan de Oro City">Claro M. Recto Ave.</option>
                            <option value="Rosario LimKetkai Ave., Lapasan, Cagayan de Oro City">Rosario LimKetkai Ave.</option>
                            <option value="Sto. Nino St., Lapasan, Cagayan de Oro City">Sto. Nino St.</option>
                            <option value="Inter-Sitio Access St., Lapasan, Cagayan de Oro City">Inter-Sitio Access St.</option>
                            <option value="Gaabucayan St., Lapasan, Cagayan de Oro City">Gaabucayan St.</option>
                            <option value="Kabukiran St., Lapasan, Cagayan de Oro City">Kabukiran St.</option>
                            <option value="Baconga St., Lapasan, Cagayan de Oro City">Baconga St.</option>
                            <option value="San Juan Access Rd., Lapasan, Cagayan de Oro City">San Juan Access Rd.</option>
                            <option value="Coastal Rd., Lapasan, Cagayan de Oro City">Coastal Rd.</option>
                            <option value="Bajas Rd., Lapasan, Cagayan de Oro City">Bajas Rd.</option>
                            <option value="Sta Cruz 2 Rd., Lapasan, Cagayan de Oro City">Sta. Cruz 2 Rd.</option>
                            <option value="Hillside Rd., Lapasan, Cagayan de Oro City">Hillside Rd.</option>
                            <option value="Valenzuela Rd., Lapasan, Cagayan de Oro City">Valenzuela Rd.</option>
                            <option value="Mambato St., Lapasan, Cagayan de Oro City">Mambato St.</option>
                        </select>
                    </div>
                </div><br>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="lStatus">LIVING STATUS:</label>
                    <div class="col-sm-2"> 
                        <select name="lStatus" id="lStatus" class="form-control" required>
                            <option value="<?= $lStatus ?>"><?= $lStatus ?></option>
                            <option value="Active">Active</option>
                            <option value="Deceased">Deceased</option>
                        </select>
                    </div>
                </div>

                <?php } ?>
                <?php } ?>

                <br><br><br>
                <div class="form-group"> 
                    <center>
                        <div class="col-sm-12 col-lg-8">
                            <button type="submit" class="btn btn-default" style="background-color: rgb(192,0,0); color:white;">Update Resident</button>
                        </div>
                    </center>
                </div>
            </form>
        </center>
    </div>
</div>