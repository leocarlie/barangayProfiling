

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard" style="padding-bottom:0;">
                <div class="row">
                    <div class="col-md-8">
                        <h2>Queue Clearance Here</h2>
                    </div>
                    
                    
                        <div class="col-md-4" style="background-color: grey; padding:5px;">
                        <center>
                            <form action="<?= $_SERVER['PHP_SELF']; ?>" style="border-width: 0; padding:0;">
                                <input type="text" name="searchkey" placeholder="Enter Resident Name Here">
                                <button class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                        </center>
                        </div>
                    
                </div>
                <br>
                <div class="row">
                    <div class="table-responsive">          
                        <table class="table">
                            <thead style="background-color: rgb(0, 112, 192); color:white;">
                            <tr>
                                <th>Action</th>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Status</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Position</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                                
                                if(isset($_GET['searchkey'])){
                                    $searchkey = $_GET['searchkey'];
                                    $sql = "SELECT * FROM residentsprofile WHERE firstName LIKE '%$searchkey%'";

                                    $result = mysqli_query($conn, $sql);

                                    if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_assoc($result)){

                                            $dob = $row['dateOfBirth'];

                                            $bday = new DateTime($dob); // Your date of birth
                                            $today = new Datetime(date('y.m.d'));
                                            $diff = $today->diff($bday);
                                            $age = $diff->y;

                            ?>

                            <tr>
                                <td>
                                    <a href="reviewCR.php?residentID=<?= $row['residentID']; ?>&searchkey=<?= $searchkey; ?>" style="padding: 0;"><i class="fas fa-eye" style="color: black;"></i></a>
                                    <a href="chooseClearance.php?residentID=<?= $row['residentID']; ?>&searchkey=<?= $searchkey; ?>" style="padding: 0;"><i class="fas fa-file" style="color: blue;"></i></a>
                                </td>
                                <td><?= $row['residentID']; ?></td>
                                <td><?= $row['lastName']; ?>, <?= $row['firstName']; ?> <?= $row['midName']; ?> <?= $row['suffix']; ?></td>
                                <td><?= $age; ?></td>
                                <td><?= $row['gender']; ?></td>
                                <td><?= $row['civilStatus']; ?></td>
                                <td><?= $row['address']; ?></td>
                                <td><?= $row['contactNum']; ?></td>
                                <td><?= $row['brgyposition']; ?></td>
                            </tr>
                            <?php 
                                    }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>            
        </div>
    </div>
</div>
<?php 
    } else{ echo "Name not Found!"; } }
?>
<!--end of center content-->