<div class="row bgbanner ">
    <div class="p-0 col-md-2">
        <center>
        <img class="img-responsive logo" src="images/lapasanLogo.png" alt="Barangay Logo" width="150" height="auto">
        </center>
    </div>
    <div class="p-0 col-md-10">
        <center>
            <h1>BARANGAY LAPASAN</h1>
        </center>
    </div>
</div>

