

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">
                <div class="row bg-success">
                    <div class="col-md-8">
                        <h1 style="padding: 20px; color:white;">Queue Added!</h1>
                    </div>
                    <div class="col-md-2">
                        <a href="cRequest.php"><button style="float: right; color:white;" class="btn bg-primary">Queue More</button></a>
                    </div>
                    <div class="col-md-1">
                        <a href="cIssuance.php"><button style="float: right; color:white;" class="btn bg-warning">Ok</button></a>
                    </div>
                </div>
                
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>


<!--end of center content-->