
<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="cRequest.php"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin" style="width: 30px; padding:5px; background-color:green;"><a href="cPass.php" style="padding: 0;"><i class="fas fa-cog" style="font-size: 20px;"></i></a></h1>
            <h1 class="admin" style="margin-left: 0;"><i class="fas fa-user" style="margin-right: 5px;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
                
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">
                <div class="row">
                    <div class="col-md-6 dboard bg-success">
                        <a href="enrollResident.php"><h1>Enroll Resident</h1></a>
                    </div>
                    <div class="col-md-5 dboard bg-warning">
                        <a href="residentsProfile.php"><h1>Update Resident</h1></a>
                    </div>
                </div>
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>

<!--end of center content-->
