

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="cRequest.php"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard" style="padding:10px 20px 20px 20px; margin:20px 0px 20px 0px;"><br>
                
                <div class="row">
                    <div class="col-md-8">
                        <a href="residentsProfile.php" style="padding:0;"><i class="fas fa-arrow-circle-left" style="margin-right: 0; color:blue; font-size:25px;"></i></a>
                        <h4 style="display: inline; margin-left:10px;">Resident's Information</h4>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <center>
                            <i class="fas fa-user-circle" style="margin-right: 0; margin-top:5px; color:gray; font-size:100px;"></i>
                        </center>
                    </div>
                </div>
                            <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = $resID";
                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $addDetails = $row['addDetails'];
                                        $address = $row['address'];
                                        $position = $row['brgyposition'];
                                        $cont = $row['contactNum'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                                    }
                                }
                            ?> 
                <br>
                <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Residen ID</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $resID; ?> </b> </h6>
                            </div>
                        </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Name</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $fname; ?> <?= $mname; ?> <?= $lname; ?> <?= $suffix; ?></b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Barangay Position</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $position; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Contact Number</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $cont; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Date Of Birth</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $dob; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Civil Status</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $status; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Gender</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $gender; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Age</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $age; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center"  style="margin-bottom:0;  margin:0px;">
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="background-color: gray;">
                                <h6 style="color: white; padding:8px 2px 0 2px;">Address</h6>
                            </div>
                        </div>
                        <div class="row" style="padding: 10px;">
                            <div class="col-md-12" style="border-style: solid; border-width:2px; border-color:gray;">
                                <h6 style="padding:7px 2px 0 2px; color:black;"> <b> <?= $addDetails; ?> <?= $address; ?> </b> </h6>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
                
                
            </div>
        </div>
        <div>
            <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
        </div>
    </div>
</div>

<!--end of center content-->