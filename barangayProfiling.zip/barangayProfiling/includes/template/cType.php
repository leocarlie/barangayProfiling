<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/brgyLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="blotterRecords.php"><i class="fas fa-scroll"></i>Blotter Records</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="#"><i class="fas fa-business-time"></i>Settlement</a></li>
                    <li><a href="#"><i class="fas fa-question"></i>Report</a></li><br>
                    <li><a href="#"><i class="fas fa-arrow-circle-right"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Dan David</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">
                <div class="container" style="background-color:gray; padding:10px;">
                    <div class="row OCIFormrow1 p-1 align-items-center">
                        <a href="residentsProfile.php"><i class="fas fa-window-close" style="color: white; font-size:40px;"></i></a>
                        <h1 style="color: white; margin-top:10px;">Select Clearance Type</h1>
                    </div>
                    <div style="margin: 20px; padding: 10px; background-color:white;">


                        <form class="form-horizontal OCIForm" role="form" method="get" action="BCForm.php" style="border-width: 0; padding: 0;">

                            <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";


                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;

                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">BARANGAY CLEARANCE</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr>




                        <form class="form-horizontal OCIForm" role="form" method="get" action="CIForm.php" style="border-width: 0; padding: 0;"">

                        <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">CERTIFICATE OF INDIGENCY</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr>



                        <form class="form-horizontal OCIForm" role="form" method="get" action="CRForm.php" style="border-width: 0; padding: 0;">

                        <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">CERTIFICATE OF RESIDENCY</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr>





                        <form class="form-horizontal OCIForm" role="form" method="get" action="ECForm.php" style="border-width: 0; padding: 0;">

                        <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">CERTIFICATION FOR ELECTRICAL CONNECTION</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr>




                        <form class="form-horizontal OCIForm" role="form" method="get" action="WCForm.php" style="border-width: 0; padding: 0;">

                        <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">CERTIFICATION FOR WATER CONNECTION</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr>




                        <form class="form-horizontal OCIForm" role="form" method="get" action="BPForm.php" style="border-width: 0; padding: 0;">

                        <?php
                                $resID = $_GET['residentID'];
                                $sql = "SELECT * FROM residentsprofile WHERE residentID = '$resID'";

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) == 1){
                                    while($row = mysqli_fetch_assoc($result)){

                                        $fname = $row['firstName'];
                                        $mname = $row['midName'];
                                        $lname = $row['lastName'];
                                        $suffix = $row['suffix'];
                                        $dob = $row['dateOfBirth'];
                                        $gender = $row['gender'];
                                        $status = $row['civilStatus'];
                                        $address = $row['address'];

                                        $bday = new DateTime($dob); // Your date of birth
                                        $today = new Datetime(date('y.m.d'));
                                        $diff = $today->diff($bday);
                                        $age = $diff->y;
                            ?>

                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="fname">FIRST NAME:</label>
                                <div class="col-sm-8">
                                    <input type="text" name="fname" class="form-control" value="<?= $row['firstName']; ?>" placeholder="Enter Your First Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="mname">MIDDLE NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="mname" value="<?= $row['midName']; ?>" class="form-control" placeholder="Enter Your Middle Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="lname">LAST NAME:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="lname" value="<?= $row['lastName']; ?>" class="form-control" placeholder="Enter Your Last Name Here" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="suffix">SUFFIX:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="suffix" value="<?= $row['suffix']; ?>" class="form-control" placeholder="Enter Your Suffix Name Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="age">AGE:</label>
                                <div class="col-sm-8"> 
                                    <input type="number" name="age" value="<?= $age; ?>" class="form-control" placeholder="Enter Your Age" required>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">CIVIL STATUS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="status" value="<?= $row['civilStatus']; ?>" class="form-control" placeholder="Enter Your Civil Status Here">
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="address">ADDRESS:</label>
                                <div class="col-sm-8"> 
                                    <input type="text" name="address" value="<?= $row['address']; ?>" class="form-control" placeholder="Enter Your Address Here">
                                </div>
                            </div>
                                <?php } ?>
                            <?php } ?>

                            <br>
                            <div class="form-group"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(0,153,255); color:white; padding:20px;">CERTIFICATION FOR BUSINESS PERMIT</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                        <hr style="padding: 0;">




                    </div>
                </div>
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>



<!--end of center content-->