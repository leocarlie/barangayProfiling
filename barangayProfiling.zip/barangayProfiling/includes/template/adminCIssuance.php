

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="cRequest.php"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->

        <?php
            include_once('utilities/dbconnect.php');

            $sql = "SELECT * FROM clearanceRequest";
            $sqlPending = "SELECT * FROM clearanceRequest WHERE status LIKE '%Pending%'";
            $sqlReleased = "SELECT * FROM clearanceRequest WHERE status LIKE '%Released%'";
            $sqlIndigency = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%1%' AND status LIKE '%Pending%'";
            $sqlResidency = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%2%' AND status LIKE '%Pending%'";
            $sqlBrgyClearance = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%4%' AND status LIKE '%Pending%'";
            $sqlBPermit = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%3%' AND status LIKE '%Pending%'";
            $sqlWConnection = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%5%' AND status LIKE '%Pending%'";
            $sqlEConnection = "SELECT * FROM clearanceRequest WHERE documentID LIKE '%6%' AND status LIKE '%Pending%'";


            $result = mysqli_query($conn, $sql);    
            if ($result){ 
                // it return number of rows in the table. 
                $row = mysqli_num_rows($result); 
                
                    if ($row) { 
                        $totalReq = $row; 
                    }else{
                        $totalReq = "0";
                    }
                // close the result. 
                mysqli_free_result($result); 
            }
            
            
            $resPending = mysqli_query($conn, $sqlPending);    
            if ($resPending){ 
                // it return number of rows in the table. 
                $row = mysqli_num_rows($resPending); 
                
                    if ($row) { 
                        $totalPending = $row; 
                    }else{
                        $totalPending = "0";
                    }
                // close the result. 
                mysqli_free_result($resPending); 
            }

            $resReleased = mysqli_query($conn, $sqlReleased);   
            if ($resReleased){ 
                // it return number of rows in the table. 
                $row = mysqli_num_rows($resReleased); 
                
                    if ($row) { 
                        $totalReleased = $row; 
                    }else{
                        $totalReleased = "0";
                    }
                // close the result. 
                mysqli_free_result($resReleased); 
            }

            $resIndi = mysqli_query($conn, $sqlIndigency);   
            if ($resIndi){
                $row = mysqli_num_rows($resIndi); 
                    if ($row) { 
                        $totalIndi = $row; 
                    }else{
                        $totalIndi = "0";
                    } 
                mysqli_free_result($resIndi); 
            }

            $resRes = mysqli_query($conn, $sqlResidency);   
            if ($resRes){
                $row = mysqli_num_rows($resRes); 
                    if ($row) { 
                        $totalRes = $row; 
                    }else{
                        $totalRes = "0";
                    } 
                mysqli_free_result($resRes); 
            }

            $resBClearance = mysqli_query($conn, $sqlBrgyClearance);   
            if ($resBClearance){
                $row = mysqli_num_rows($resBClearance); 
                    if ($row) { 
                        $totalBC = $row; 
                    }else{
                        $totalBC = "0";
                    } 
                mysqli_free_result($resBClearance); 
            }

            $resBP = mysqli_query($conn, $sqlBPermit);   
            if ($resBP){
                $row = mysqli_num_rows($resBP); 
                    if ($row) { 
                        $totalBP = $row; 
                    }else{
                        $totalBP = "0";
                    } 
                mysqli_free_result($resBP); 
            }

            $resWC = mysqli_query($conn, $sqlWConnection);   
            if ($resWC){
                $row = mysqli_num_rows($resWC); 
                    if ($row) { 
                        $totalWC = $row; 
                    }else{
                        $totalWC = "0";
                    } 
                mysqli_free_result($resWC); 
            }

            $resEC = mysqli_query($conn, $sqlEConnection);   
            if ($resEC){
                $row = mysqli_num_rows($resEC); 
                    if ($row) { 
                        $totalEC = $row; 
                    }else{
                        $totalEC = "0";
                    } 
                mysqli_free_result($resEC); 
            }
        ?>
        <div class="container-fluid">
            <div class="admindashboard">
                
                <div class="row" style="box-shadow: 1px 1px 10px .5px grey;">
                    <div class="col-md-2.5 align-items-center bg-primary info">
                        <h5>Total: <b>[ <?= $totalReq; ?> ]</b></h5>
                    </div>
                    <div class="col-md-2.5 bg-success info">
                        <h5>Released: <b>[ <?= $totalReleased; ?> ]</b></h5>
                    </div>
                    <div class="col-md-2.5 bg-danger info">
                        <h5>Pending: <b>[ <?= $totalPending; ?> ]</b></h5>
                    </div>
                </div>
                <div class="row" style="padding:30px;"></div>
                <div class="row">
                    <div class="col-md-3 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalIndi; ?></h4>
                        <a href="viewIRequest.php" style="color:black;">
                            <h1>Indigency</h1>
                        </a>
                    </div>
                    <div class="col-md-3 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalRes; ?></h4>
                        <a href="viewRRequest.php" style="color:black;">
                            <h1>Residency</h1>
                        </a>
                    </div>
                    <div class="col-md-5 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalBP; ?></h4>
                        <a href="viewBPRequest.php" style="color:black;">
                            <h1>Business Permit</h1>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalBC; ?></h4>
                        <a href="viewBCRequest.php" style="color:black;">
                            <h1>Brgy. Clearance</h1>
                        </a>
                    </div>
                    <div class="col-md-3 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalWC; ?></h4>
                        <a href="viewWCRequest.php" style="color:black;">
                            <h1>Water Connection</h1>
                        </a>
                    </div>
                    <div class="col-md-5 cCard">
                        <h4 style="float: right; color:white; background-color: red; padding: 2px 10px 2px 10px; border-radius:50px 50px 50px 50px;"><?= $totalEC; ?></h4>
                        <a href="viewECRequest.php" style="color:black;">
                            <h1>Electrical Connection</h1>
                        </a>
                    </div>
                </div>
                
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>


<!--end of center content-->