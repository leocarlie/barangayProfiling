<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Dan David</title>
    <link rel="stylesheet" href="styles/all.min.css">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/all.css">

    <style>
        body{
            background: rgb(242, 242, 242);
            font-family: gurmukhi;
        }

        .centerContent{
            height: 500px;
        }

        .sidebar{
            background-color: rgb(0,32,96);
            font-size: 20px;
            padding-top: 10px;
        }

        i{
            margin-right: 13px;
        }

        a{
            color: white;
            padding-left: 30px;
        }

        a:hover{
            color: white;
            text-decoration: none;
        }

        nav{
            margin-top: 15px;
        }

        li{
            padding: 8px 0 8px 0;
        }

        li:hover{
            background-color: rgb(0 0 0);
            color: white;
        }        

        div.row1{
            background-color: white;
            height: 50px;
        }

        h1.admin{
            background-color: rgb(192 0 0);
            color: white;
            font-size: 20px;
            text-align: center;
            margin:5px;
            padding:5px;
        }

        h3.name{
            font-size: 25px;
            padding: 5px;
            margin: 5px;
        }

        h1.logout{
            background-color: grey;
            color: white;
            font-size: 20px;
            text-align: center;
            margin:5px;
            padding:5px;
        }
        
        div.admindashboard{
            background-color: white;
            border-radius: 10px;
            margin: 15px;
            padding: 50px;
            box-shadow: 1px 1px 10px .5px grey;
        }

        div.dboard{
            margin: 10px;
            padding: 45px;
            background-color: yellow;
            text-align: center;
            color: white;
        }

        form{
            border-width: 5px;
            border-color: rgb(192, 0, 0);
            border-style: dashed;
            padding: 20px;
            color: rgb(192, 0, 0);
        }


        .enrollrow1{
            background-color: rgb(192, 0, 0);
            margin-top: 10px;
        }

        .resbutton{
            border-width: 0;
            background-color: white;
            padding: 2px;
            font-size: 20px;
        }

        .cb{
            background-color: rgb(255, 192, 0);
            padding: 20px;
            text-align: center;
            margin-top: 30px;
        }

        .OCIFormrow1{
            background-color: rgb(0, 153, 255);
            margin-top: 10px;
        }

        form.OCIForm{
            border-width: 5px;
            border-color: rgb(0, 153, 255);
            border-style: dashed;
            padding: 20px;
            color: rgb(192, 0, 0);
        }

        div.choices:hover{
            box-shadow: 1px 1px 1px 0px black;
            border-radius: 100px;
        }

        div.info{
            margin: 10px;
            padding: 5px 20px 1px 20px;
            color: white;
        }

        div.cCard{
            padding: 10px;
            margin: 10px;
            box-shadow: 1px 1px 10px .5px grey;
        }

        div.cCard:hover{
            border-radius:20px 20px 20px 20px;
            background-color: gray;
            box-shadow: 0px 0px 0px 0px grey;
        }




        footer{
            background-color: rgb(0,32,96);
            color: white;
            height: 50px;
            padding: 15px;
        }

    </style>

</head>
<body>
    <!--Body starts here-->
    <div class="container-fluid">