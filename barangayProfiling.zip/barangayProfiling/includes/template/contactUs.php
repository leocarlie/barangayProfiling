<?php
    include_once('utilities/dbconnect.php');
?>
  
    <div class="col-md-10">
    
        <div class="contentcontainer container-fluid">
            <div class="row">
                <div class="col-md-11 contentboxes">
                    <h6 style="font-size:30px;">Contact Us!</h6>
                    <div class="col-md-12 col-sm-12 bg-success mt-4">
                        <center>
                            <h5 class="p-4" style="color:white;"><i class="fas fa-phone"></i>09398885941 / 09967688972<pre style="display: inline;">     </pre> <i class="fas fa-envelope"> </i>brgyprofiling.service@gmail.com</h5>
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div>
            <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
        </div>
    </div>
<!--Center content ends here-->
</div>