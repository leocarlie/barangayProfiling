

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <?php
        $resID = $_GET['residentID'];
        $searchkey = $_GET['searchkey'];
    ?>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">
                
                <div class="row">
                    <div class="col-md-12">
                    <div class="row p-1 align-items-center bg-primary">
                    <a href="cRequest.php?searchkey=<?= $searchkey; ?>"><i class="fas fa-window-close" style="color: white; font-size:40px;"></i></a>
                    <h1 style="color: white; margin-top:10px;">Clearance Queueing</h1>
                </div>
                        <form action="transactions/rClearance.php" method="post" style="border-width: 0 5px 5px 5px; border-color: blue">
                        <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="id"></label>
                                <div class="col-sm-6"> 
                                    <input name="id" type="text" value="<?= $resID; ?>">
                                </div>
                            </div>


                        <center>
                            <div class="form-group">
                                <label class="control-label col-sm-4" for="ctype">SELECT CLEARANCE:</label>
                                <div class="col-sm-6"> 
                                    <select name="ctype" id="ctype" class="form-control" required>
                                        <option value="" disabled selected>Select</option>
                                        <option value="1">Certificate of Indigency</option>
                                        <option value="2">Certificate of Residency</option>
                                        <option value="3">Certification for Business Permit</option>
                                        <option value="4">Barangay Clearance</option>
                                        <option value="5">Certification for Water Connection</option>
                                        <option value="6">Certification for Electrical Connection</option>
                                    </select>
                                </div>  
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-4" for="purpose">PURPOSE:</label>
                                <div class="col-sm-6"> 
                                    <select name="purpose" id="purpose" class="form-control" required>
                                        <option value="" disabled selected>Select</option>
                                        <option value="Scholarship">Scholarship</option>
                                        <option value="Financial Assistance">Financial Assistance</option>
                                        <option value="NBI Clearance">NBI Clearance</option>
                                        <option value="Police Clearance">Police Clearance</option>
                                        <option value="Tax Exemption">Tax Exemption</option>
                                        <option value="Business Permit">Business Permit</option>
                                        <option value="Water Connection">Water Connection</option>
                                        <option value="Electrical Connection">Electrical Connection</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group" style="display: none;">
                                <label class="control-label col-sm-4" for="status">STATUS:</label>
                                <div class="col-sm-6"> 
                                    <select name="status" id="status" class="form-control" required>
                                        <option value="Pending">Pending</option>
                                        <option value="Released">Released</option>
                                    </select>
                                </div>
                            </div>
                            <button class="btn btn-primary">Queue A Clearance</button>
                        </center>
                        </form>
                    </div>
                </div>
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>


<!--end of center content-->