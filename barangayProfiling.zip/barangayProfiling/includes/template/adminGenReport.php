

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="cRequest.php"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li><a href="cIssuance.php"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">
                <div class="row">
                    <div class="col-md-12">
                        <h1>Generate Reports Here!</h1>
                        <form class="form-horizontal" role="form" method="get" action="transactions/genRep.php">

                            <div class="form-group">
                                <label class="control-label col-sm-4">APPLY REPORT FILTER: <i class="fas fa-filter" style="color: green;"></i></label>
                            </div>

                            <div class="form-group">
                                <div class="col-sm-8"> 
                                    <select name="list" class="form-control" onchange="yesnoCheck(this);" required>
                                        <option value="residents">List All Residents</option>
                                        <option value="gender">List All Residents with Gender</option>
                                        <option value="requested">List All Residents with Clearance Requested</option>
                                        <option value="issued">List All Residents with Clearance Issued</option>
                                    </select>
                                </div>
                            </div>

                            <script type="text/javascript">
                                function yesnoCheck(that){
                                    if(that.value == "gender"){
                                        document.getElementById("ifGender").style.display = "block";
                                    }else{
                                        document.getElementById("ifGender").style.display = "none";
                                    }

                                    if(that.value == "requested" || that.value == "issued"){
                                        document.getElementById("ifCType").style.display = "block";
                                    }else{
                                        document.getElementById("ifCType").style.display = "none";
                                    }                                 
                                }
                            </script>

                            <div id="ifGender" class="form-group" style="display: none;">
                                <div class="col-sm-8">Gender:
                                    <select name="gender" class="form-control">
                                        <option value="">Select Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                            </div>

                            <div id="ifCType" class="form-group" style="display: none;">
                                    <div class="col-sm-8">Clearance Type:
                                        <select name="cType" class="form-control">
                                            <option value="">Select Clearance Type</option>
                                            <option value="1">Certificate of Indigency</option>
                                            <option value="2">Certificate of Residency</option>
                                            <option value="3">Certification for Business Permit</option>
                                            <option value="4">Barangay Clearance</option>
                                            <option value="5">Certification for Water Connection</option>
                                            <option value="6">Certification for Electrical Connection</option>
                                        </select>
                                    </div>  
                            </div>

                            <div class="form-group" style="float:right;"> 
                                <center>
                                    <div class="col-sm-12 col-lg-8">
                                        <button type="submit" class="btn btn-default" style="background-color: rgb(192,0,0); color:white; width:200px; border-color:white; border-width:5px;">Generate Report</button>
                                    </div>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>
<!--end of center content-->