<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Dan David</title>
    <link rel="stylesheet" href="styles/all.min.css">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="styles/all.css">

    <style>
        body{
            background: rgb(242, 242, 242);
            font-family: gurmukhi;
        }



        .logo{
            margin: 10px;
        }

        .bgbanner{
            background-image: url("images/header.png");
            background-size: cover;
            background-color: rgb(0,32,96);
            border-width: 0 0 5px 0;
            border-style: solid;
            border-color: rgb(192 0 0)
        }

        h1{
            color: white;
            font-size: 85px;
            margin-top: 30px;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .centerContent{
            height: 500px;
        }

        .sidebar{
            background-color: rgb(0,32,96);
            font-size: 20px;
            padding-top: 10px;
        }

        i{
            margin-right: 15px;
        }

        a{
            color: white;
            padding-left: 40px;
        }

        a:hover{
            color: white;
            text-decoration: none;
        }

        nav{
            margin-top: 15px;
        }

        li{
            padding: 8px 0 8px 0;
        }

        li:hover{
            background-color: rgb(0 0 0);
        }

        div.contentcontainer{
            border-radius: 5px 5px 5px 5px;
            background-color: rgb(191, 191, 191);
            margin-top: 15px;
        }

        div.contentboxes{
            background-color: white;
            margin: 20px;
            padding: 0px;
            height: 195px;
            box-shadow: 10px 10px 10px .5px grey;
        }

        h6{
            margin-left: 0;
            margin-right: 0;
            margin-top: 10px;
            padding: 5px;
            text-align: center;
            font-size: 20px;
            background-color: rgb(255 192 0);
        }

        div.populationnumber{
            background-color: rgb(0 176 80);
            box-shadow: 0px 5px 20px 1px grey;
            margin: 20px;
        }

        div.male{
            background-color: blue;
            width: 150px;
            border-radius: 10px;
            padding-bottom: 5px;
        }  

        div.female{
            background-color: rgb(201, 17, 113);
            width: 150px;
            border-radius: 10px;
            padding-bottom: 5px;
        }

        h1.population{
            font-size: 60px;
            text-align: center;
        }

        h1.male{
            font-size: 20px;
            text-align: center;
            padding: 0;
            margin: 0;
        }

        h1.female{
            font-size: 20px;
            text-align: center;
            padding: 0;
            margin: 0;
        }

        h6.gender{
            background-color:white;
            font-size: 15px;
            margin: 0;
        }

        div.more{
            background-color: rgb(0 176 80);
            border-radius: 5px;
            width: 150px;
            margin-top: 35px;
            padding: 5px;
            box-shadow: 0px 5px 20px 1px grey;
        }

        h1.more{
            font-size: 30px;
            text-align: center;
            margin-top: 5px;
        }

        div.devBox{
            background-color: white;
            box-shadow: 0px 5px 20px 1px grey;
            margin: 40px;
        }

        footer{
            background-color: rgb(0,32,96);
            color: white; 
        }

    </style>

</head>
<body>
    <!--Body starts here-->
    <div class="container-fluid">