<?php
    include_once('utilities/dbconnect.php');
?>
  
    <div class="col-md-10">
    
        <div class="contentcontainer container-fluid">
            <div class="row">
                <div class="col-md-11 devBox">
                    <h6 style="font-size:30px;">Developers Information</h6>
                    <center>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4" style="float: left; border-style:solid; border-width: 0 5px 0 0; border-color:black;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Dan David Abanilla</h3>
                                <pre class="pb-1" style="color: yellow;">Project Manager</pre>
                            </center>
                        </div>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4" style="float: right; border-style:solid; border-width: 0 0 0 5px; border-color:red;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Danielle Agustine</h3>
                                <pre class="pb-1" style="color: yellow;">Project Documentation</pre>
                            </center>
                        </div>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4" style="float: left; border-style:solid; border-width: 0 5px 0 0; border-color:red;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Leo Carlie Abato</h3>
                                <pre class="pb-1" style="color: yellow;">System Developer</pre>
                            </center>
                        </div>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4" style="float: right; border-style:solid; border-width: 0 0 0 5px; border-color:black;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Peter Babia</h3>
                                <pre class="pb-1" style="color: yellow;">UI Designer/Tester</pre>
                            </center>
                        </div>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4" style="float: left; border-style:solid; border-width: 0 5px 0 0; border-color:black;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Rejan Vincent Onting</h3>
                                <pre class="pb-1" style="color: yellow;">System Developer</pre>
                            </center>
                        </div>
                        <div class="col-md-6 col-sm-12 bg-secondary mt-4 mb-4" style="float: right; border-style:solid; border-width: 0 0 0 5px; border-color:red;">
                            <center>
                                <h3 class="pt-3 mb-0" style="color:white;"><i class="fas fa-user-circle"></i>Richie Marie Gatela</h3>
                                <pre class="pb-1" style="color: yellow;">UI Designer/Tester</pre>
                            </center>
                        </div>
                        
                        
                    </center>
                </div>
            </div>
        </div>
        <br>
        <div>
            <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
        </div>
    </div>
<!--Center content ends here-->
</div>