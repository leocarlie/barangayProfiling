

<div class="row centerContent">
    <div class="col-md-2 sidebar p-0">
        <center>
            <img src="images/lapasanLogo.png" alt="Barangay Logo" width="150px;" style="margin-top: 30px;">
        </center>    
        <br>
        <nav class=" p-0">
            <div class="container-fluid p-0">
                <ul class="p-0">
                    <li><a href="admin.php"><i class="fas fa-boxes"></i>Dashboard</a></li>
                    <li><a href="residentsProfile.php"><i class="fas fa-users"></i>Resident's Profile</a></li>
                    <li><a href="cRequest.php"><i class="fas fa-bell"></i>Clearance Request</a></li>
                    <li style="background-color: rgb(192, 0, 0);"><a href="#"><i class="fas fa-file"></i>Clearance Issuance</a></li>
                    <li><a href="genReport.php"><i class="fas fa-file-export"></i>Generate Report</a></li><br><br>
                    <li><a href="transactions/adminLogout.php"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
                    <br>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-md-10">
        <div class="row row1 align-items-center">
            <h1 class="admin"><i class="fas fa-user" style="margin-right: 0;"></i> ADMIN</h1>
            <h3 class="name">Barangay Lapasan</h3>
        </div>
        <!--Admin dashboard starts here-->
        <div class="container-fluid">
            <div class="admindashboard">

            <?php
                include_once('utilities/dbconnect.php');
                $sqlPending = "SELECT * FROM clearanceRequest WHERE documentID = 4 AND status LIKE '%Pending%'";
                $sqlReleased = "SELECT * FROM clearanceRequest WHERE documentID = 4 AND status LIKE '%Released%'";

                $resPending = mysqli_query($conn, $sqlPending);    
                if ($resPending){ 
                    // it return number of rows in the table. 
                    $row = mysqli_num_rows($resPending); 
                    
                        if ($row) { 
                            $totalPending = $row; 
                        }else{
                            $totalPending = "0";
                        }
                    // close the result. 
                    mysqli_free_result($resPending); 
                }

                $resReleased = mysqli_query($conn, $sqlReleased);   
                if ($resReleased){ 
                    // it return number of rows in the table. 
                    $row = mysqli_num_rows($resReleased); 
                    
                        if ($row) { 
                            $totalReleased = $row; 
                        }else{
                            $totalReleased = "0";
                        }
                    // close the result. 
                    mysqli_free_result($resReleased); 
                }

            ?>
                
                <div class="row">
                    <div class="col-md-8" style="padding:4px;">
                        <a href="cIssuance.php" style="padding:0;"><i class="fas fa-arrow-circle-left" style="margin-right: 0; color:blue; font-size:40px;"></i></a>

                        <h2 style="display: inline; margin-left:10px;">Brgy. Clearance</h2>
                        
                        <span style="margin-right:50px; margin-left:20px; float:right; font-size:20px;">Released: <b style="color:red;"><?= $totalReleased; ?></b></span>
                        <span style="float:right; font-size:20px;">Pending: <b style="color:red;"><?= $totalPending; ?></b></span>
                    </div>
                    
                    
                        <div class="col-md-4" style="background-color: grey; padding:5px;">
                        <center>
                            <form action="<?= $_SERVER['PHP_SELF']; ?>" style="border-width: 0; padding:0;">
                                <input type="text" name="searchkey" placeholder="Enter Resident's ID Here">
                                <button class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                        </center>
                        </div>
                    
                </div>
                <br>
                <div class="row">
                    <div class="table-responsive">          
                        <table class="table">
                            <thead style="background-color: rgb(0, 112, 192); color:white;">
                            <tr>
                                <th>Action</th>
                                <th>Request#</th>
                                <th>ResidentID</th>
                                <th>Purpose</th>
                                <th>Status</th>
                                <th>Date Requested</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                                $sql = "SELECT * FROM clearancerequest WHERE documentID = 4 ORDER BY requestID DESC";
                                
                                if(isset($_GET['searchkey'])){
                                    $searchkey = $_GET['searchkey'];
                                    $sql = "SELECT * FROM clearancerequest WHERE resID LIKE '%$searchkey%' AND documentID = 4";
                                }
                            

                                $result = mysqli_query($conn, $sql);

                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                                        
                                    


                            ?>

                            <tr>
                                <td>
                                    <a href="BCForm.php?requestID=<?= $row['requestID']; ?>" style="padding: 0;"><i class="fas fa-file" style="color: green;"></i></a>
                                </td>
                                <td><?= $row['requestID']; ?></td>
                                <td><?= $row['resID']; ?></td>
                                <td><?= $row['requestPurpose']; ?></td>
                                <td><?= $row['status']; ?></td>
                                <td><?= $row['requestDate']; ?></td>
                            </tr>
                            <?php 
                                    }}
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div>
                <center><footer>All Rights Reserved | Barangay Profiling &copy; 2020</footer></center>
            </div>
        </div>
    </div>
</div>


<!--end of center content-->